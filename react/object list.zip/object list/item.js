class Item{
    name="";
    amount = 0;


constructor(name,amount) {
    this.name = name;
    this.amount = amount;
}

}